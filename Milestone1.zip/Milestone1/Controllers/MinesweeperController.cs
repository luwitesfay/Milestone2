﻿using Microsoft.AspNetCore.Mvc;
using Milestone1.Services;
using Milestone1.Models;

namespace Milestone1.Controllers
{
    private readonly MinesweeperService minsweeperService;
    public class MinesweeperController : Controller
    {
        public MinesweeperController(MinesweeperService minsweeperService)
        {
            minsweeperService = minsweeperService;
        }

        public IActionResult Index()
        {

            var model = minsweeperService.CreateBoard(10, 10, 20);
            return View(model);
        }

        [HttpPost]
        public IActionResult RevealCell(int x, int y)
        {

            var model = GetCurrentBoard();

            minsweeperService.RevealCell(model, x, y);


            SaveCurrentBoard(model);

            return Json(new
            {
                cellData = new
                {
                    isRevealed = model.Cells[x, y].IsRevealed,
                    isMine = model.Cells[x, y].IsMine,
                    neighboringMines = model.Cells[x, y].NeighboringMines
                }
            });
        }

        private MinesweeperModel GetCurrentBoard()
        {
            return minsweeperService.CreateBoard(10, 10, 20);
        }

        private void SaveCurrentBoard(MinesweeperModel model)
        {
            // SaveUpdate
        }
    }
}
