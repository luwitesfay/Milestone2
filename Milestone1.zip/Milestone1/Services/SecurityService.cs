﻿using Milestone1.Models;

namespace Milestone1.Services
{
	public class SecurityService
	{
		public SecurityDAO securityDAO = new SecurityDAO();
		public SecurityService()
		{
			SecurityDAO securityDAO = new SecurityDAO();

		}

		public bool IsValid(UserModel user)
		{
			return securityDAO.InsertUser(user);

		}
	}
}
