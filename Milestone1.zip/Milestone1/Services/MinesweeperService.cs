﻿using Milestone1.Models;

namespace Milestone1.Services
{
    public class MinesweeperService
    {
        private Random _random = new Random();

        public MinsweeperModel CreateBoard(int width, int height, int mineCount)
        {
            MinsweeperModel board = new MinsweeperModel
            {
                Width = width,
                Height = height,
                Cells = new CellModel[width, height]
            };

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    board.Cells[i, j] = new CellModel();
                }
            }

            for (int i = 0; i < mineCount; i++)
            {
                int x, y;
                do
                {
                    x = _random.Next(width);
                    y = _random.Next(height);
                } while (board.Cells[x, y].IsMine);

                board.Cells[x, y].IsMine = true;
            }

            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    if (!board.Cells[x, y].IsMine)
                    {
                        board.Cells[x, y].NeighboringMines = CalculateNeighboringMines(board, x, y);
                    }
                }
            }

            return board;
        }

        public MinsweeperModel RevealCell(MinsweeperModel model, int x, int y)
        {
            if (x < 0 || x >= model.Width || y < 0 || y >= model.Height)
                return model;

            if (model.Cells[x, y].IsRevealed)
                return model;

            if (model.Cells[x, y].IsMine)
            {
                
                model.Cells[x, y].IsRevealed = true;

            }
            else
            {
                RevealSafeCells(model, x, y);
            }

            return model;
        }

        private void RevealSafeCells(MinsweeperModel model, int x, int y)
        {
            if (x < 0 || x >= model.Width || y < 0 || y >= model.Height || model.Cells[x, y].IsRevealed)
                return;

            model.Cells[x, y].IsRevealed = true;

            if (model.Cells[x, y].NeighboringMines == 0)
            {
                for (int i = -1; i <= 1; i++)
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        if (i == 0 && j == 0)
                            continue;

                        RevealSafeCells(model, x + i, y + j);
                    }
                }
            }
        }

        private int CalculateNeighboringMines(MinsweeperModel board, int x, int y)
        {
            int count = 0;

            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i == 0 && j == 0)
                        continue;

                    int checkX = x + i;
                    int checkY = y + j;

                    if (checkX >= 0 && checkX < board.Width && checkY >= 0 && checkY < board.Height)
                    {
                        if (board.Cells[checkX, checkY].IsMine)
                            count++;
                    }
                }
            }

            return count;
        }
    }
}
